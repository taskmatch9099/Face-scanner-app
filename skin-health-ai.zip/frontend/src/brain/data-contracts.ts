export type HandleHealthzData = any;
